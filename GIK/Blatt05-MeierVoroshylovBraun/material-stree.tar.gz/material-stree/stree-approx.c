#include "core/unused_api.h"
#include "gt_suffixtree.h"
#include "stree-approx.h"

/* remove GT_UNUSED once the function is completly implemented */

void stree_approx_pattern_match(GT_UNUSED const GtStree *stree,
                                GT_UNUSED const GtUchar *pattern,
                                GT_UNUSED GtUword len,
                                GT_UNUSED GtUword differences)
{
  return;
}
