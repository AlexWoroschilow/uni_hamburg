#include "core/unused_api.h"
#include "gt_suffixtree.h"
#include "stree-minunique.h"

/* remove GT_UNUSED once the function is completly implemented */

int gt_stree_minunique(GT_UNUSED const char *indexname,
                       GT_UNUSED GtUword minlength,
                       GT_UNUSED bool withsequence,
                       GT_UNUSED GtError *err)
{
  return 0;
}
