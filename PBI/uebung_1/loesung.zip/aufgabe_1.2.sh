#! /bin/sh

echo ">> Aufgabe 1.2"

echo ">> Anzahl der Zeilen in datei1: "`cat "./datei1" | wc -l`
echo ">> Anzahl der Zeilen in datei2: "`cat "./datei2" | wc -l`

echo ">> Versuchen jetzt die Namen tauschen: "`mv "./datei1" "./datei3"; mv "./datei2" "./datei1"; mv "./datei3" "./datei2"; `

echo ">> Anzahl der Zeilen in datei1: "`cat "./datei1" | wc -l`
echo ">> Anzahl der Zeilen in datei2: "`cat "./datei2" | wc -l`
