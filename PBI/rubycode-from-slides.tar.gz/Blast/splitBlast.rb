require "get_file_data.rb"

# Split BLAST output file

# parse beginning and ending annotation, and alignments,
# from BLAST output file

def splitblastoutput(filename)
  # Get the BLAST program output into an array from a file

  blast_output_file = get_file_data(filename).join

  # Extract the beginning annotation, alignments, and ending annotation 
  # beginning_annotation is everything up to line starting with ALIGNMENTS 
  # alignment_section contains all alignments and goes until keyword Database 
  # appears at line with two blanks indented. use modifier m: . matches \n

  matchData = blast_output_file.match(/(.*^ALIGNMENTS\n)(.*)(^  Database:.*)/m)
  
  if not matchData
    STDERR.puts "#{$0}: Illegal input in blast file #{filename}"
    exit 1
  end
  # Assign values for annotation and alignment from match results
  beginning_annotation, alignment_section, ending_annotation = matchData[1..3]
  alignments = parse_blast_alignment(alignment_section)
  return beginning_annotation, ending_annotation, alignments
end

# parse the alignments from a BLAST output file, return hash with 
# key = ID and value = text of alignment





def parse_blast_alignment (alignment_section)
  alignmenttable = Hash.new()

  # loop through the scalar containing the BLAST alignments,
  # extracting the ID and the alignment and storing in a hash
  
  # The regular expression matches a line beginning with > and containing
  # the ID between the first pair of | characters; followed by any number of 
  # lines that don't begin with >. Here (?!>) is a negative lookahead assertion 
  # meaning that the line is not allowed to begin with >

  alignment_section.scan(/(^>.*\n(^(?!>).*\n)+)/) do |entry|
    val = entry[0]
    keytab = val.split(/\|/)      # split it at pattern |
    key = keytab[1]               # extract second element, which is the 
                                  # accession number of the sequence
    if alignmenttable.has_key?(key)
      STDERR.puts "#{$0}: there is already an alignment for key \"#{key}\""
      exit 1
    end
    alignmenttable[key] = val     # store the alignment in hash
  end
  return alignmenttable
end
