#!/usr/bin/env ruby

floatval = 2323.14159265
intval = 76
stringval = "hello world"

# use formatted print to show these lines:

printf "A float\t\t  \"%6.4f\"\n", floatval
printf "An integer\t  \"%-5d\"\n", intval
printf "A string\t  \"%s\"\n", stringval
