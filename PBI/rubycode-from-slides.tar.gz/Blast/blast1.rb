#!/usr/bin/env ruby

require "splitBlast.rb"

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <blastoutputfile>"
  exit 1
end

blastoutputfile = ARGV[0]

beginning_annotation, ending_annotation, alignments = splitblastoutput(blastoutputfile)

puts "XXXXXXXXXXXXXXXXXXXX begin first part XXXXXXXXXXXXXXXX"
puts beginning_annotation
puts "XXXXXXXXXXXXXXXXXXXX end first part XXXXXXXXXXXXXXXX"

alignments.each_pair do |key, val|
  puts "XXXXXXXXX Alignment of query against #{key} XXXXXXX"
  puts val
  puts "XXXXXXXXXXXX end of Alignment XXXXXXXXXXX"
end

puts "XXXXXXXXXXXXXXXXXX begin last part XXXXXXXXXXXXXXXXXX"
puts ending_annotation
puts "XXXXXXXXXXXXXXXXXX end last part XXXXXXXXXXXXXXXXXX"
