#!/usr/bin/env ruby
# Parse alignments from BLAST output file

require "print_sequence.rb"
require "splitBlast.rb"
require "splitAlign.rb"

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <blastoutputfile>"
  exit 1
end

blastoutputfile = ARGV[0]

beginning_annotation, ending_annotation, alignments = splitblastoutput(blastoutputfile)

# process the alignments one after the other

alignments.each_pair do |key, alignment|
  hsps = parse_blast_alignment_HSP(alignment)

  hsps.shift
  hsps.each do |hsp|
    expect, query, query_range, subject, subject_range = extract_HSP_information(hsp)
  
    puts "###################"
    print ">align Query(#{query_range}) with "
    print "Subject=#{key}(#{subject_range}), expected = #{expect}\n"
    print_sequence(query,70)
    puts ">"
    print_sequence(subject,70)
  end
end
