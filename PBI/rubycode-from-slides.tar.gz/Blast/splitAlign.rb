# Parse alignments from BLAST output file
# First parse beginning annotation, and HSPs, from BLAST alignment
# Return an array with first element set to the beginning annotation,
# and each successive element set to an HSP

def parse_blast_alignment_HSP (alignment)
  hsps = Array.new()

  # Extract the beginning annotation and HSPs
  matchdata = alignment.match(/(.*?)(^ Score =.*)/m)
  
  if not matchdata
    STDERR.puts "#{$0}: Cannot parse alignment"
    exit 1
  end
  beginning_annotation, hsp_section = matchdata[1..2]
  # .* is used with non-greedy or minimal matching operator "?"  which means
  # to match everything before the first appearance of the keyword Score

  # Store the value of beginning_annotation as first entry in array hsps
  hsps.push(beginning_annotation)

  # Parse the HSPs, store each HSP as an element in hsps. Each HSP 
  # begins with Score = and extends until before the next appearance of 
  # Score =. This is expressed via ?! stating a negative lookahead 
  # assertion: match the following lines that do _not_ begin with Score =

  hsp_section.scan(/(^ Score =.*\n(^(?! Score =).*\n)+)/) do |entry|
    hsps.push(entry[0])
  end

  # Return array with first element = the beginning annotation,
  # and each successive element = an HSP
  return hsps
end

# parse HSP from BLAST output alignment section, return values:
# Expect value; Query string; Query range; Subject string; Subject range

def extract_HSP_information(hsp)
  
  # expect gets value to the right of Expect =
  matchdata = hsp.match(/Expect = (\S+)/)
  if matchdata == nil
    STDERR.puts "#{$0}: Cannot find occurrence of \"Expect = \""
    exit 1
  end
  expect = matchdata[1]

  # extract all lines beginning with Query: and concatenate them 

  query = hsp.scan(/^Query(.*)\n/).join

  # extract all lines beginning with Subject: and concatenate them
  # this is done in the same way as extracting the query lines

  subject = hsp.scan(/^Sbjct(.*)\n/).join

  # select first and last number from all query lines
  # this is achieved by a pattern consisting of four parts:
  # part 1: match any number of digits
  # part 2: match any sequence of character including newline
  #         due to the use of the modifier m
  # part 3: match any character which is not digit
  # part 4: match any number of digits
  # as a result we get a list of two numbers which is concatenated with ..

  query_range = query.scan(/(\d+).*\D(\d+)/m).join('..')

  # select first and last number from all subject lines
  # in analogy to query_range

  subject_range = subject.scan(/(\d+).*\D(\d+)/m).join('..')

  # select everything which is a base. this is achieved by
  # substituting all characters except for bases

  query.gsub!(/[^acgt]/i,"")
  subject.gsub!(/[^acgt]/i,"")

  return expect, query, query_range, subject, subject_range
end
