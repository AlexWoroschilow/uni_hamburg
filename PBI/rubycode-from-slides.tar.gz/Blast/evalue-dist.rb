#!/usr/bin/env ruby

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <blast-outputfile.xml>"
  exit 1
end

evalues = Array.new()
logdist = Hash.new()
minusinfinity = 0
File.new(ARGV[0],"r").each_line do |line|
  mo = line.match(/<Hsp_evalue>(.*)<\/Hsp_evalue>/)
  if mo
    f = mo[1].to_f
    evalues.push(f)
    dlog = Math.log10(f)
    if dlog.infinite?.nil?
      decadiclog = dlog.floor
      if logdist.has_key?(decadiclog)
        logdist[decadiclog] += 1
      else
        logdist[decadiclog] = 1
      end
    else
      minusinfinity += 1
    end
  end
end
evalues.sort.each do |f|
  puts f
end
puts "-infinity #{minusinfinity}"
logdist.sort.each do |elem|
  dlog = elem.shift
  dist = elem.shift
  puts "#{dlog} #{dist}"
end
