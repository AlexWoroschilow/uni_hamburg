#list the contents of a directory,
#recursively listing the contents of any subdirectories

def listdirectory(directory)
  # prepare regexp for entries to ignore 
  # saves time for repeated regexp use, since it stays the same
  ignore_dirs = Regexp.compile(/^\.\.?$/)
  
  begin
    # Iterate over items in directory
    Dir.foreach(directory) do |entry|
    
      # We ignore current and parent directory entries here
      unless entry.match(ignore_dirs)
        # directory entry is a regular file
        if File.stat("#{directory}/#{entry}").file?
          puts "#{directory}/#{entry}"
        # directory entry is a subdirectory
        elsif File.stat("#{directory}/#{entry}").directory?
          # Here is the recursive call to this function
          listdirectory("#{directory}/#{entry}")
        end
      end
    end
  rescue
    # We got here because of some error. Report error and exit.
    STDERR.puts "Error accessing directory #{directory}."
    exit 1
  end
end
