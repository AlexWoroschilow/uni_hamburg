#!/usr/bin/env ruby
puts <<HEREDOC
Reference: Altschul, Stephen F., Thomas L. Madden, Alejandro A. Schaffer,
Jinghui Zhang, Zheng Zhang, Webb Miller, and David J. Lipman (1997),
"Gapped BLAST and PSI-BLAST: a new generation of protein database search
programs",  Nucleic Acids Res. 25:3389-3402.
RID: 991533563-27495-9092
HEREDOC

["GEZ\nKoeln", "Versicherung\nHamburg", "BFA\nBerlin"].each do |address|
print "------------------------------------------------------------\n";
print <<HEREDOC
                                                   Hamburg, den 1.11.2012

#{address}

Joe User
Universitaetsstrasse 25
33613 Bielefeld

Sehr geehrte Damen und Herren,

meine neue Adresse lautet: Bundeststrasse 43, 20146 Hamburg

MfG, Joe User
HEREDOC
end
