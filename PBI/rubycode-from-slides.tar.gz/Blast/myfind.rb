#!/usr/bin/env ruby
# Demonstrate a recursive subroutine to list a subtree of a filesystem

require "listdir.rb"

if ARGV.length == 1
  filename = ARGV[0]
else
  STDERR.puts "Usage: #{$0} <file or directoryname>"
  exit 1
end

if File.stat(filename).file?
  puts filename
else
  if File.stat(filename).directory?
    listdirectory(filename)
  end
end

exit 0
