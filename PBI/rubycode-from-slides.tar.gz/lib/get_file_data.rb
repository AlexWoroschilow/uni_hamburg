def get_file_data(filename, aSeparator = $/)
  if File.exist?(filename)
    begin
      file = File.new(filename,"r")
    rescue => err
      STDERR.puts "#{$0}: #{err}"
      exit 1
    end
  else 
    STDERR.puts "#{$0}: file #{filename} does not exist"
    exit 1
  end
  return file.readlines(aSeparator)
end
