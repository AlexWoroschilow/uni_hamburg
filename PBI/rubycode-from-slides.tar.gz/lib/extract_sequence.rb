def extract_sequence_from_fasta_data(filename)
  seq = ''
  File.new(filename,"r").each_line do |line|
    if not line.match(/^(>|\s*$|\s*#)/)
      seq += line
    end
  end
  return seq.gsub(/\s/,"")
end
