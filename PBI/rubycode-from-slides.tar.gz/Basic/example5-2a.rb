#!/usr/bin/env ruby
# Example 5-2   Reading protein sequence data from a file, take 4

# The filename of the file containing the protein sequence data
proteinfilename = 'NM_021964fragment.pep'

begin
  proteinfile = File.new(proteinfilename,"r")
rescue
  puts "Cannot open file #{proteinfilename}"
  exit 1
end

# Read the protein sequence data from the file via an iterator,
# printing each line as it is read.
proteinfile.each_line do |line|
  puts "  ######  Here is the next line of the file:"
  print line
end

proteinfile.close

exit 0
