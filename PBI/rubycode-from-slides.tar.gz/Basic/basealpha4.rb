#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
base1 = bases.pop
puts "The element removed from the end: #{base1}"
puts "The remaining array of bases: #{bases}"
