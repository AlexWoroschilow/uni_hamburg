#!/usr/bin/env ruby

# Example 4-1   Storing DNA in a variable, and printing it out
# First we store the DNA in a variable called dna
dna = 'ACGGGAGGACGGGAAAATTACTACGGCATTAGC'

# Next, we print the DNA onto the screen
puts dna

# Finally, we'll specifically tell the program to exit.
exit 0
