#!/usr/bin/env ruby
# Example 5-2   Reading protein sequence data from a file, take 4

# The filename of the file containing the protein sequence data
proteinfilename = 'NM_021964fragment.pep'

begin
  proteinfile = File.new(proteinfilename,"r")
rescue => err
  STDERR.puts "#{$0}: cannot open file #{proteinfilename}: #{err}"
  exit 1
end

# Read the protein sequence data from the file in a "while" loop,
# printing each line as it is read.
begin
  while protein = proteinfile.readline do
    puts "  ######  Here is the next line of the file:\n#{protein}"
  end
# When we have reached the end, close file.
rescue EOFError
  proteinfile.close
end

exit 0
