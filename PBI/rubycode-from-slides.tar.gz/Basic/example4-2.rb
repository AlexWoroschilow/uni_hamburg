#!/usr/bin/env ruby
# Example 4-2   Concatenating DNA

# Store two DNA fragments into two variables called dna1 and dna2
dna1 = 'ACGGGAGGACGGGAAAATTACTACGGCATTAGC'
dna2 = 'ATAGTGCCGTGAGAGTGATGTAGTA'

# Print the DNA onto the screen
print "Here are the original two DNA fragments:\n\n"

puts dna1
puts dna2, "\n"

# Concatenate DNA fragments into a third variable and print them
# using "string interpolation"
dna3 = "#{dna1}#{dna2}"

puts "Concatenation of the first two fragments (version 1):\n"

puts "#{dna3}\n"

# An alternative way using the concatenation operator:
# Concatenate DNA fragments into a third variable and print them
dna3 = dna1 + dna2

puts "Concatenation of the first two fragments (version 2):\n"

puts "#{dna3}\n"

# Print the same thing without using the variable dna3
puts "Concatenation of the first two fragments (version 3):\n"

print dna1, dna2, "\n"

exit 0
