#!/usr/bin/env ruby
# Example 5-1   if-elsif-else

word = 'MNIDDKL'

# if-elsif-else conditionals
if word == 'QSTVSGE'
    puts "QSTVSGE"
elsif word == 'MRQQDMISHDEL'
    puts "MRQQDMISHDEL"
elsif word == 'MNIDDKL'
    puts "MNIDDKL-the magic word!"
else
    puts "Is \"#{word}\" a peptide? This program is not sure."
end

exit 0
