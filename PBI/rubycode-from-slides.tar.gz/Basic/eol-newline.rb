#!/usr/bin/env ruby

File.new("filewitoutlastnewline.txt","r").each do |line|
  puts "line=>#{line}<"
end
