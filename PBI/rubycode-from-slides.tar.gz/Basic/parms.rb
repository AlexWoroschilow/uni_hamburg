#!/usr/bin/env ruby

# Here, the parameters are named, and the order when 
# passing determines assignment. You can also do this:

def func1(a, b, c)
  puts "#{__method__}: #{a} #{b} #{c}"
end

func1(1, 2, 3)

# Here, the third parameter has a default, so it can be 
# omitted if desired, in order to use the default value.

def func2(a, b, c=3)
  puts "#{__method__}: #{a} #{b} #{c}"
end

func2(1, 2)
func2(1, 2, 5)

# Next, the '*' operator lets you do variable argument 
# lists. All "extra" arguments get put into an array 
# in the variable specified.

def func3(a, b, *otherargs)
  puts "#{__method__}: #{a} #{b} #{otherargs.join(' ')}"
end

# a=1, b=2, otherargs=[3,4,5]
func3(1, 2, 3, 4, 5)
# a=1, b=2, otherargs=[]
func3(1, 2)
