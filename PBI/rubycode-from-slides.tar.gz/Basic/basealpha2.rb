#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
puts "The array elements: #{bases}"
