#!/usr/bin/env ruby
# Example 4-3   Transcribing DNA into RNA

# The DNA
dna = 'ACGGGAGGACGGGAAAATTACTACGGCATTAGC'

# Print the DNA onto the screen
puts "Here is the starting DNA:\n"

puts "#{dna}\n"

# Transcribe the DNA to RNA by substituting all T's with U's.
rna = dna.gsub(/T/,'U')

# Print the RNA onto the screen
puts "Here is the result of transcribing the DNA to RNA:\n"

puts "#{rna}"

exit 0
