#!/usr/bin/env ruby
# Example 6-1  program with a function to append ACGT to DNA

def addACGT(dnaparam)
  dnaparam += 'ACGT'
  return dnaparam
end

# The original DNA
dna = 'TGCA'

# The call to the function "addACGT".
# The argument being passed in is "dna"
# the result is saved in "longer_dna"
longer_dna = addACGT(dna)

puts "I added ACGT to #{dna} and got #{longer_dna}"
