#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
print "The array elements: "
puts bases.join(" ")
