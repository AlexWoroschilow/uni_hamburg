#!/usr/bin/env ruby

poem = ["My toast has flown from my hand",
        "And my toast has gone to the moon.",
        "But when I saw it on television,",
        "Planting our flag on Halley's comet,",
        "More still did I want to eat it."]

puts poem.join("\n")
