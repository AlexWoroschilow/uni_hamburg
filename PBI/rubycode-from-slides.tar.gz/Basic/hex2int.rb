#!/usr/bin/env ruby

def hextoint(cc)
  if cc >= 48 and cc <= 57 # a digit
    return cc - 48
  elsif cc >= 65 and cc <= 70
    return 10 + cc - 65
  else
    STDERR.puts "#{$0}: illegal character in hex-number"
    exit 1
  end
end

def hex2toint(s)
  if s.length != 2
    STDERR.puts "#{$0}: #{s}.length = #{s.length} not expected"
    exit 1
  end
  return hextoint(s[0]) * 16 + hextoint(s[1])
end
