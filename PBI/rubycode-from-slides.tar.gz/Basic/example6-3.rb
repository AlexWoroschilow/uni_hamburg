#!/usr/bin/env ruby
# Example 6-3   Count number of G's in some DNA from command line

# Collect DNA from the arguments on the command line
# If no arguments are given, print a USAGE statement and exit.

def countG(dna)
  # return a count of the number of G's in the argument dna
  # Use the String object's built-in method "count" to determine
  # abundance of "g"s.
  return dna.downcase.count("g")
end

# $0 is a special variable that has the name of the program.
USAGE = "Usage: #{$0} DNA"

# ARGV is an array containing all command-line arguments. If it is
# empty, the test will fail and the print USAGE and exit statements
# will be called.
if ARGV.length != 1
  STDERR.puts USAGE
  exit 1
end

# Read in the DNA from the argument on the command line.
dna = ARGV[0]

# Call the function, collect the result and print it.
num_of_Gs = countG(dna)
puts "The DNA #{dna} has #{num_of_Gs} G\'s in it!"
