#!/usr/bin/env ruby

def passintandstrings(p1,p2,p3)
  p1 = 5
  p2 = "five"
  p3.capitalize!
  puts "in #{__method__}: p1=#{p1} p2=#{p2} p3=#{p3}"
end

intval, str1, str2 = 3, "three", "five"
passintandstrings(intval,str1,str2)
puts "end: intval=#{intval} str1=#{str1} str2=#{str2}"
