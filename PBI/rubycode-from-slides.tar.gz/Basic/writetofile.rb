#!/usr/env ruby
outputfilename = "countbase" 

# write the results to a file named countbase
begin
  countbase = File.new(outputfilename,"w")
rescue
  STDERR.puts "Cannot open file #{outputfilename}!"
  exit 1
end

countbase.puts "A=#{countA} C=#{countC} G=#{countG} T=#{countT}"
countbase.close
