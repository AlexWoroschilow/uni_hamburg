#!/bin/sh
for filename in `find -name '*.pl' -maxdepth 1 -type f`
do
  newfile=.tmp
  sed -e 's/^>//' ${filename} > ${newfile}
  mv ${newfile} ${filename}
done
