#!/usr/bin/env ruby

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} < filename>"
  exit 1
end

begin
  f = File.new(ARGV[0],"r")
rescue => err
  STDERR.puts "Cannot open file #{ARGV[0]}: #{err}"
  exit 1
end

def changefirstchar(s)
  a = s.split('')
  a[0] = a[0].downcase
  return a.join
end

f.readlines.each do |x|
  puts(changefirstchar(x))
end
