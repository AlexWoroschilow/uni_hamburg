#!/usr/bin/env ruby 

# Get the name of the file with the DNA sequence data
print "Please type the filename of the DNA sequence data: "
dnafilename = STDIN.gets

# Remove the newline from the DNA filename
dnafilename.chomp!

# open the file, or exit
if File.exist?(dnafilename)
  begin
    dnafile = File.new(dnafilename,"r")
  rescue => err
    STDERR.puts "Cannot open file #{dnafilename}: #{err}"
    exit 1
  end
else 
  STDERR.puts "File #{dnafilename} does not exist!"
  exit 1
end

# Read the DNA sequence data from the file, and store it
# as a concatenated string in the variable "dna"
dna = dnafile.read

# Close the file
dnafile.close

# Remove whitespace
dna.gsub!(/\s/,"")

# Now explode the DNA into an array where each letter of the
# original string is now an element in the array.
# This will make it easy to look at each position.
dna = dna.split(//)

# Initialize the counts.
count_of_A = 0
count_of_C = 0
count_of_G = 0
count_of_T = 0
errors     = 0

# In a loop, look at each base in turn, determine which of the
# four types of nucleotides it is, and increment the
# appropriate count.
dna.each do |base|
  if base == 'A'
    count_of_A += 1
  elsif base == 'C'
    count_of_C += 1
  elsif base == 'G'
    count_of_G += 1
  elsif base == 'T'
    count_of_T += 1
  else
    STDERR.puts "Error - I don\'t recognize this base: #{base}"
    errors += 1
  end
end

puts "A = #{count_of_A}"
puts "C = #{count_of_C}"
puts "G = #{count_of_G}"
puts "T = #{count_of_T}"
puts "errors = #{errors}"
exit 0
