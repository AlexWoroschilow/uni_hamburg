#!/usr/bin/env ruby
# Example 5-4   Determining frequency of nucleotides

# Get the name of the file with the DNA sequence data
print "Please type the filename of the DNA sequence data: "
dnafilename = STDIN.gets

# Remove the newline from the DNA filename
dnafilename.chomp!

# open the file, or exit
if File.exist?(dnafilename)
  begin
    dnafile = File.new(dnafilename,"r")
  rescue
    STDERR.puts "Cannot open file #{dnafilename}!"
    exit 1
  end
else 
  STDERR.puts "File #{dnafilename} does not exist!"
  exit 1
end

# Read the DNA sequence data from the file, and store it
# as a concatenated string in the variable "dna"
dna = dnafile.readlines.join

# Close the file
dnafile.close

# Remove whitespace
dna.gsub!(/\s/,"")

# Now explode the DNA into an array where each letter of the
# original string is now an element in the array.
# This will make it easy to look at each position.
dna = dna.split(//)

# Initialize the counts.
count_of_A = 0
count_of_C = 0
count_of_G = 0
count_of_T = 0
errors     = 0

# In a loop, look at each base in turn, determine which of the
# four types of nucleotides it is, and increment the
# appropriate count.
dna.each do |base|
    if base == 'A' or base == 'a'
        count_of_A += 1
    elsif base  == 'C' or base == 'c'
        count_of_C += 1
    elsif base == 'G' or base == 'g'
        count_of_G += 1
    elsif base == 'T' or base == 't'
        count_of_T += 1
    else
        errors += 1
    end
end

# print the results
puts "A = #{count_of_A}"
puts "C = #{count_of_C}"
puts "G = #{count_of_G}"
puts "T = #{count_of_T}"
puts "errors = #{errors}"
gccount = count_of_C + count_of_G
totallength = dna.length
printf("GC-content: %.1f\n",100.0 * gccount/totallength)
