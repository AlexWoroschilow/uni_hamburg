#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
base1 = bases.pop
bases.unshift(base1)
puts "An element from the end put on the beginning: #{bases}"
