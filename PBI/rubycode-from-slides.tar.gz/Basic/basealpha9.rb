#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
bases.insert(2,"X")  
print "The array with an element inserted after the 2nd element: "
puts "#{bases}"
