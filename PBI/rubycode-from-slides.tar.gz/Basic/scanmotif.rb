#!/usr/bin/env ruby 

# Ask the user for the filename of the file containing
# the protein sequence data, and collect it from the keyboard
print "type filename of the protein sequence: "
proteinfilename = STDIN.gets

# Remove the trailing newline from the protein filename
proteinfilename.chomp!

# open the file, or exit
begin
  proteinfile = File.new(proteinfilename,"r")
rescue
  STDERR.puts "Cannot open file #{proteinfilename}!"
  exit 1
end

# Read the protein sequence data from the file, and store it
# into the array variable "protein"
protein = proteinfile.readlines

# Close the file - we've read all the data into "protein" now.
proteinfile.close

# Put the protein sequence data into a single string, as it's 
# easier to search for a motif in a string than in an array 
# of lines (what if the motif occurs over a line break?)
proteinseq = protein.join

# Remove whitespace and '>' symbols
proteinseq.gsub!(/(\s|\>)/,"")

# In a loop, ask the user for a motif, search for the motif, 
# and report if it was found. break out of the loop if no 
# motif is entered.
loop do
  print "Enter a motif to search for: "
  motif = STDIN.gets
  motif.chomp!
  puts "checking motif \"#{motif}\"" 
  if motif.match(/^\s*$/)
    break
  end
  if motif.match(/^quit$/)
    break
  end
  puts "searching motif \"#{motif}\"" 
  if proteinseq.match(/#{motif}/)
    puts "I found it!"
  else
    puts "I couldn\'t find it."
  end
end
