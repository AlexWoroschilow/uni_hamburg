#!/usr/bin/env ruby
# Example 4-6 Reading protein sequence data from a file, take 2

# The filename of the file containing the protein sequence data
proteinfilename = '../Basic/NM_021964fragment.pep'

# First we have create a new File object.
# We name it "proteinfile" for readability.
proteinfile = File.new(proteinfilename, "r")

# Now we reading the protein sequence data from the file
# by calling the "readline" method of the File object.
#
# Since the file has three lines, and since the read only is
# returning one line, we'll read a line and print it, three times.

# First line
protein = proteinfile.readline

# Print the protein onto the screen
puts "Here is the first line of the protein file:\n#{protein}"

# Second line
protein = proteinfile.readline

# Print the protein onto the screen
puts "Here is the second line of the protein file:\n#{protein}"

# Third line
protein = proteinfile.readline

# Print the protein onto the screen
puts "Here is the third line of the protein file:\n#{protein}"

# Now that we've got our data, we can close the file.
proteinfile.close

exit 0
