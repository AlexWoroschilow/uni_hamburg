#!/usr/bin/env ruby

english2german = 
{
  'dog'   => 'Hund',
  'robin' => 'Rotkehlchen',
  'asp'   => 'Natter'
}

english2german['pearl'] = "Perle"

puts "dog=#{english2german['dog']}"
puts "pearl=#{english2german['pearl']}"

puts "#{english2german.keys.join(",")}"
puts "#{english2german.values.join(",")}"

if english2german.has_key?('cat')
  puts "cat=#{english2german['cat']}"
else
  STDERR.puts "#{$0}: no translation for 'cat'"
  exit 1
end
