#!/usr/bin/env ruby
# Example 4-7   Reading protein sequence data from a file, take 3

# The filename of the file containing the protein sequence data
proteinfilename = 'NM_021964fragment.pep'

# First we create a file object
proteinfile = File.new(proteinfilename, "r")

# Read protein sequence data from file, and store it into array
proteins = proteinfile.readlines

proteins.each_with_index do |line, idx|
  print "#{idx+1}: #{line}"   # Print line with linnumber
end
proteinfile.close     # Close the file.

exit 0
