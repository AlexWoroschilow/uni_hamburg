#!/usr/bin/env ruby
# Example 5-3   Searching for motifs

# Ask the user for the filename of the file containing
# the protein sequence data, and collect it from the keyboard
print "Please type the filename of the protein sequence data: "
proteinfilename = STDIN.gets

# Remove the newline from the protein filename
proteinfilename.chomp!

begin
  proteinfile = File.new(proteinfilename,"r")
rescue => err
  STDERR.puts "#{$0}: could not open file #{proteinfilename}: #{err}"
  exit 1
end

# Read the protein sequence data from the file, and store it
# into the array variable "protein"
lines = proteinfile.readlines

# Close the file - we've read all the data into "protein" now.
proteinfile.close

# Put the protein sequence data into a single string, as it's easier
# to search for a motif in a string than in an array of
# lines (what if the motif occurs over a line break?)
proteinseq = lines.join

# Remove whitespace and '>' symbols
proteinseq.gsub!(/\s|\>/,"")

puts "\"#{proteinseq}\""

# In a loop, ask the user for a motif, search for the motif,
# and report if it was found.
# Exit if no motif is entered.
begin
  print "Enter a motif to search for: "
  motif = STDIN.gets

  # Remove the newline at the end of the motif
  motif.chomp!

  # Look for the motif
  m = proteinseq.match(/#{motif}/)
  if m
    puts "I found \"#{motif}\" as #{m[0]}"
  else
    puts "I couldn\'t find #{motif}"
  end
# exit on an empty user input
end until motif.match(/^\s*$/)

# exit the program
exit 0
