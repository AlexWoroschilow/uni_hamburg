#!/usr/env ruby
dna = dnafile.readlines.join

countA = dna.scan(/a/i).length
countC = dna.scan(/c/i).length
countG = dna.scan(/g/i).length
countT = dna.scan(/t/i).length
errors = dna.scan(/[^acgt]/i).length

puts "A=#{countA} C=#{countC} G=#{countG} T=#{countT}"
puts "errors=#{errors}"
