#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
base2 = bases.shift
bases.push(base2)
puts "An element from the beginning put on the end: #{bases}"
