#!/usr/bin/env ruby

def pushshift(itab,jtab)
  puts "in function: itab = #{itab}"
  puts "in function: jtab = #{jtab}"
  itab.push('4')
  jtab.shift
end

itab = ['1','2','3']
jtab = ['a','b','c']

puts "in main before calling pushshift: itab = #{itab}"
puts "in main before calling pushshift: jtab = #{jtab}"

pushshift(itab,jtab)

puts "in main after calling pushshift: itab = #{itab}"
puts "in main after calling pushshift: jtab = #{jtab}"
