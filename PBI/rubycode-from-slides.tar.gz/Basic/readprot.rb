#!/usr/bin/env ruby 

proteinfilename = 'NM_021964fragment.pep'
puts "Try to open \"#{proteinfilename}\""

# First we have to open the file, and in case the
# open fails, print an error message and exit the program.
begin
  proteinfile = File.new(proteinfilename,"r")
rescue => err
  STDERR.puts "Cannot open file #{proteinfilename}: #{err}"
  exit 1
end

# Read protein sequence data from file in a block
proteinfile.each do |line|
  puts "  ######  Here is the next line of the file:"
  print line
end
proteinfile.close
