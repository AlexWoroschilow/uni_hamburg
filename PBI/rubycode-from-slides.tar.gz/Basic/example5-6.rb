#!/usr/bin/env ruby
# Example 5-6   Determining frequency of nucleotides, take 2

# Get the name of the file with the DNA sequence data
print "Please type the filename of the DNA sequence data: "
dnafilename = gets
dnafilename.chomp!

if File.exist?(dnafilename)
  begin
    dnafile = File.new(dnafilename,"r")
  rescue
    STDERR.puts "Cannot open file #{dnafilename}"
    exit 1
  end
else 
  STDERR.puts "File #{dnafilename} does not exist"
  exit 1
end

# Read the DNA sequence data from the file, and store it
# as a concatenated string in the variable "dna"
dna = dnafile.readlines.join

# Close the file
dnafile.close

# Remove whitespace
dna.gsub!(/\s/,"")

# Initialize the counts.
count_of_A = 0
count_of_C = 0
count_of_G = 0
count_of_T = 0
errors     = 0

# In a loop, look at each base in turn, determine which of the
# four types of nucleotides it is, and increment the
# appropriate count.
for position in 0..(dna.length-1)
    base = dna[position..position]
    if base == 'A'
        count_of_A += 1
    elsif base  == 'C'
        count_of_C += 1
    elsif base == 'G'
        count_of_G += 1
    elsif base == 'T'
        count_of_T += 1
    else
        puts "Error - I don\'t recognize this base: #{base}"
        errors += 1
    end
end

# print the results
puts "A = #{count_of_A}"
puts "C = #{count_of_C}"
puts "G = #{count_of_G}"
puts "T = #{count_of_T}"
puts "errors = #{errors}"
