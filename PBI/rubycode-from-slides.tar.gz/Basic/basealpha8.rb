#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
puts "The length of the array: #{bases.length}"
