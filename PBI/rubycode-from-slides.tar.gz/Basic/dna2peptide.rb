require 'Basic/transcription_table'

### This class is used for translating dna strings to amino acid strings
class DnaTranslator

include TranscriptionTable # for @@transcription_table

### Translate a dna string to an amino acid string
def translate dna
  unless dna.respond_to? :to_s
    raise ArgumentError, "Class need to be convertable to a String."
  end
  mydna = dna.to_s

  aa_sequence = String.new
  # Translate each three-base codon into an amino acid, and append to a protein 
  mydna.scan(/[acgtACGT]{3}/) do |codon|
    aa_sequence += @@transcription_table[codon.upcase]
  end
  return aa_sequence
end

end
