#!/usr/bin/env ruby
# Example 5-7   Determining frequency of nucleotides, take 3

# Get the name of the file with the DNA sequence data
print "Please type the filename of the DNA sequence data: "
dnafilename = gets
dnafilename.chomp!

if File.exist?(dnafilename)
  begin
    dnafile = File.new(dnafilename,"r")
  rescue
    STDERR.puts "Cannot open file #{dnafilename}!"
    exit 1
  end
else 
  STDERR.puts "File #{dnafilename} does not exist!"
  exit 1
end

dna = dnafile.readlines.join
dnafile.close
dna.gsub!(/\s/,"")

a, c, g, t, e = 0, 0, 0, 0, 0

# Use a regular expression "trick", and five loops,
#  to find the counts of the four bases plus errors
dna.scan(/a/i) { a+=1 }
dna.scan(/c/i) { c+=1 }
dna.scan(/g/i) { g+=1 }
dna.scan(/t/i) { t+=1 }
dna.scan(/[^acgt]/i) { e+=1 }
    
print "A=#{a} C=#{c} G=#{g} T=#{t} errors=#{e}\n"

# Also write the results to a file called "countbase"
outputfilename = "countbase"

begin
  countbase = File.new(outputfilename,"w")
rescue
  STDERR.print "Cannot open file #{outputfilename}!\n"
  exit 1
end

countbase.puts "A=#{a} C=#{c} G=#{g} T=#{t} errors=#{e}"
countbase.close

exit 0
