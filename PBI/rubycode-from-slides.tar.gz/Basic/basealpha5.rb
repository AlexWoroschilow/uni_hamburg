#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
base2 = bases.shift
puts "The element removed from the beginning: #{base2}"
puts "The remaining array of bases: #{bases}"
