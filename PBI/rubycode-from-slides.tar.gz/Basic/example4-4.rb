#!/usr/bin/env ruby
# Example 4-4   Calculating the reverse complement of a DNA-strand

dna = 'ACGGGAGGACGGGAAAATTACTACGGCATTAGC'
puts "Here is the DNA:\n"
puts "#{dna}\n"

# Calculate the reverse complement Warning: this attempt will fail!
# First, copy the DNA into new variable revcom 
# (short for REVerse COMplement)
# It doesn't matter if we first reverse the string and then do the 
# complementation; or if we first do the complementation and 
# then reverse the string. Same result each time. So when we 
# make the copy we'll do the reverse in the same statement.

revcom = dna.reverse

# Next substitute all bases by their complements
revcom.gsub!(/A/,"T")
revcom.gsub!(/T/,"A")
revcom.gsub!(/G/,"C")
revcom.gsub!(/C/,"G")

puts "Here is the incorrect result:\n#{revcom}"

# That didn't work right! Our reverse complement should have all 
# the bases in it, since the original DNA had all the bases-but 
# ours only has A and G! The problem is that the first two 
# substitute commands above change all the A's to T's (so 
# there are no A's) and then all the T's to A's (so all the 
# original A's and T's are all now A's). Same thing happens to 
# the G's and C's all turning into G's.

# Make a new copy of the DNA (see why we saved the original?)
revcom = dna.reverse

# See the text for a discussion of tr
revcom.tr!("ACGTacgt","TGCAtgca")

# Print the reverse complement DNA onto the screen
puts "Here is the reverse complement DNA:\n#{revcom}"
