#!/usr/bin/env ruby

def three_times   # call associated block 3 times
  yield
  yield
  yield
end
three_times {puts "Hello"}

def fib_up_to(max)
  i1 = 1
  i2 = 1
  while i1 <= max
    yield i1   # block will receive i1 as value
    tmp = i1 + i2
    i1 = i2
    i2 = tmp
  end
end

fib_up_to(1000) do |f| # block do ... end with parameter f, 
  print "#{f} "        # will be instantiated with value of i1
end
print "\n"

def fib_infinite
  i1 = 1
  i2 = 1
  loop do
    yield i1   # block will receive i1 as value
    tmp = i1 + i2
    i1 = i2
    i2 = tmp
  end
end

fib_infinite do |f|  # block do ... end with parameter f,
  if f > 1000        # will be instantiated with value of i1
    break
  end
  print "#{f} "
end
print "\n"
