#!/usr/bin/env ruby

bases = ['A', 'C', 'G', 'T']
puts "The array elements:"
puts "First element: #{bases[0]}"
puts "Second element: #{bases[1]}"
puts "Third element: #{bases[2]}"
puts "Fourth element: #{bases[3]}"
