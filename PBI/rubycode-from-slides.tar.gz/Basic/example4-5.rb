#!/usr/bin/env ruby
# Example 4-5 Reading protein sequence data from a file

# The filename of the file containing the protein sequence data
proteinfilename = "NM_021964fragment.pep"

# First we create a new File object.
# We name it "proteinfile" for readability.
proteinfile = File.new(proteinfilename, "r")

# Now we do the actual reading of the protein sequence data from the file
# by calling the "readline" method of the File object.
protein = proteinfile.readline

# Now that we've got our data, we can close the file.
proteinfile.close

# Print the protein onto the screen
puts "Here is the protein:\n#{protein}"
