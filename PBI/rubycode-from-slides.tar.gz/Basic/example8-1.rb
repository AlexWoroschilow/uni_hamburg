#!/usr/bin/env ruby
# Example 8-1   Translate DNA into protein

require "codon2aa.rb"

# Initialize variables
dna = 'CGACGTCTTCGTACGGGACTAGCTCGTGTCGGTCGC'
protein = ''

# Translate each three-base codon into an amino acid, and append to a protein 
dna.scan(/[GATC]{3}/) do |codon|
  protein += codon2aa(1,codon)
end

puts "I translated the DNA\n\n#{dna}\ninto the protein\n#{protein}"
