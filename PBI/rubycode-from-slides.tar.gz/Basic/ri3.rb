#!/usr/bin/env ruby

require "ri20min.rb"

mg = MegaGreeter.new("Phil")
mg.say_hi

