#!/usr/bin/env ruby
require "extract_sequence.rb"
require "print_sequence.rb"

dna = extract_sequence_from_fasta_data("sample.dna")
print_sequence(dna,60)
