#!/usr/bin/env ruby

require '../../../../repertoire/exercises/programmierung_in_der_bioinformatik/Ruby/fastaIterator.rb'

def mklengthtab(filename)
  lengthtab = Hash.new()
  FastaIterator.new(filename).each do |header,sequence|
    blastid = header.split(/\s/)[0]
    if lengthtab.has_key?(blastid)
      STDERR.puts "#{$0}: duplicated header \"#{blastid}\""
      exit 1
    end
    lengthtab[blastid] = sequence.length
  end
  return lengthtab
end

if ARGV.length != 4
  STDERR.puts "Usage: #{$0} <queryfile> <subjectfile> " +
              " <blastoutfile> <mincoverage>"
  exit 1
end

queryfile=ARGV[0]
subjectfile=ARGV[1]
blastoutfile=ARGV[2]
mincov=ARGV[3].to_i

if mincov < 1 or mincov > 100
  STDERR.puts "#{$0}: coverage must be in the range 1 to 100"
  exit 1
end

querylengthtab = mklengthtab(queryfile)
STDERR.puts "# #{querylengthtab.length} sequences " +
            "in #{queryfile}"
subjectlengthtab = mklengthtab(subjectfile)
STDERR.puts "# #{subjectlengthtab.length} sequences " +
            "in #{subjectfile}"

require 'blasttable.rb'

processed, selected = 0, 0
blhits = Blasttable.new(querylengthtab,subjectlengthtab,
                        blastoutfile)
blhits.each do |blasthit|
  if blasthit.querycoverage >= mincov and
     blasthit.subjectcoverage >= mincov
    showblasthit(blasthit)
    selected += 1
  end
  processed += 1
end
STDERR.puts "# #{processed} hits processed"
STDERR.puts "# #{selected} hits selected"
blhits.delete()
