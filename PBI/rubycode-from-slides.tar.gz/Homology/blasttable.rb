Blasthit = Struct.new("Blasthit",:query,
                                 :subject,
                                 :identity,
                                 :alignlength,
                                 :mismatches,
                                 :gapopenings,
                                 :queryhitstart,
                                 :queryhitend,
                                 :subjecthitstart,
                                 :subjecthitend,
                                 :evalue,
                                 :bitscore,
                                 :forwardstrand,
                                 :querycoverage,
                                 :subjectcoverage)

def showblasthit(bh)
  puts [bh.query,bh.subject,bh.identity,bh.alignlength,bh.mismatches,
        bh.gapopenings,bh.queryhitstart,bh.queryhitend,bh.subjecthitstart,
        bh.subjecthitend,bh.evalue,bh.bitscore,bh.forwardstrand,
        bh.querycoverage,bh.subjectcoverage].join("\t")
end

class Blasttable
  @querylengthtab = nil
  @subjectlengthtab = nil
  @hitfo = nil
  def initialize(querylengthtab,subjectlengthtab,blastfile)
    @querylengthtab = querylengthtab
    @subjectlengthtab = subjectlengthtab
    begin
      @hitfo  = File.new(blastfile,"r")
    rescue => err
      STDERR.puts "Cannot open file \"#{blastfile}\": #{err}"
      exit 1
    end
  end
  def delete()
    @hitfo.close_read
  end
  def coverage(hitstart,hitend,lengthtab,seqid)
    if hitend < hitstart
      STDERR.puts "#{$0}: hitend = #{hitend} < " +
                  "#{hitstart} = hitstart"
      exit 1
    end
    if lengthtab.has_key?(seqid)
      return 100.0 * (hitend - hitstart + 1).to_f/
             lengthtab[seqid].to_f
    else
      STDERR.puts "#{$0}: no length for #{seqid}"
      exit 1
    end
  end
  def each()    # the iterator
    @hitfo.each_line do |line|
    if line.match(/^[^\#]/)
      bla = line.split(/\t/)
      query, queryhitstart = bla[0], bla[6].to_i
      queryhitend = bla[7].to_i
      querycoverage = coverage(queryhitstart,
                               queryhitend,
                               @querylengthtab,
                               query)
      subject, subjecthitstart = bla[1], bla[8].to_i
      subjecthitend = bla[9].to_i
      forwardstrand = true
      if subjecthitstart > subjecthitend
        tmp = subjecthitstart
        subjecthitstart = subjecthitend
        subjecthitend = tmp
        forwardstrand = false
      end
      subjectcoverage = coverage(subjecthitstart,
                                 subjecthitend,
                                 @subjectlengthtab,
                                 subject)
      yield Blasthit.new(query,
                         subject,
                         bla[2].to_f,  # identity
                         bla[3].to_i,  # alignlength
                         bla[4].to_i,  # mismatches
                         bla[5].to_i,  # gapopenings
                         queryhitstart,
                         queryhitend,
                         subjecthitstart,
                         subjecthitend,
                         bla[10].to_f, # evalue
                         bla[11].to_i, # bitscore
                         forwardstrand,
                         querycoverage,
                         subjectcoverage)
      end
    end
  end
end
