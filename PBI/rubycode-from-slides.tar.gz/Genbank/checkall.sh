#!/bin/sh

set -e -x

TMPFILE=`mktemp TMP.XXXXXX` || exit 1
runall.sh > ${TMPFILE}
cmp -s ${TMPFILE} results.txt
rm -f ${TMPFILE}
