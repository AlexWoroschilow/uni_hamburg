#!/usr/bin/env ruby
require "splitGB.rb"
require "parseAnno.rb"

if ARGV.length == 1
  library = ARGV[0]
else
  STDERR.puts "Usage: #{$0} <genbankfile>"
  exit 1
end

fh = filename2fileobject(library) # Open library and read a record

record = get_next_record(fh) # get the first record

annotation, dna = get_annotation_and_dna(record)

fields = parse_annotation(annotation) # Extract fields of the annotation

# Print the fields
fields.each_pair do |key, value|
    puts "******** #{key} *********"
    puts value
end

exit 0
