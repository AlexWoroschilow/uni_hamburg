#!/usr/bin/env ruby
require "print_sequence.rb"

def gb2fasta(filename)
  sequence = ''    # initialize sequence string
  inseq = false    # true iff currently a sequence line is parsed
  File.new(filename,"r").each_line do |line|
    if line.match(/^\/\/\n/)     # line is end-of-record line //\n
      break       # break out of the nearest enclosing loop
    elsif inseq   # we are in a sequence
      sequence += line   # add current line to concatenation
    elsif line.match(/^ORIGIN/)    # line before sequence part
      inseq = true                 # set the inseq flag
    end
  end
  return sequence.gsub(/[\s0-9]/,"")
end

ARGV.each do |filename|
  sequence = gb2fasta(filename)
  puts ">"                     # empty fasta header
  print_sequence(sequence, 50) # print formatted, width 50
end
