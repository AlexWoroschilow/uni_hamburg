#!/usr/bin/env ruby

def show_regexp(a,re)
  if a.match(re)
    return "#{$`}<<#{$&}>>#{$'}"
  else
    return "no match"
  end
end

puts "result: #{show_regexp("AAC\nGTT",/^.*$/)}"
puts "result: #{show_regexp("AAC\nGTT",/^.*$/m)}"
