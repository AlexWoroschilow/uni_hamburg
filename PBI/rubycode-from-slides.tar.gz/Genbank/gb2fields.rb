#!/usr/bin/env ruby

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <genbankfile>"
  exit 1
end

# Get some of the information identifying the records
# LOCUS, DEFINITION, ACCESSION, ORGANISM
indef = false
definition = locus = accession = organism = ""

File.new(ARGV[0],"r").each_line do |line|
  if line.match(/^LOCUS/)
    line.sub!(/^LOCUS\s*/,"")       # delete field name at the beginning
    locus = line
  elsif line.match(/^DEFINITION/)
    line.sub!(/^DEFINITION\s*/,"")  # delete field name at the beginning
    definition = line
    indef = true                    # you are now inside the definition part
  elsif line.match(/^ACCESSION/)
    line.sub!(/^ACCESSION\s*/,"")   # delete field name at the beginning
    accession = line
    indef = false                   # now again outside the definition part
  elsif indef                       # still inside the definition
    definition.chomp!               # def part has been found, delete \n
    line.sub!(/^\s+/," ")           # repl. initial multispaces by single space
    definition += line
  elsif line.match(/^  ORGANISM/)   # delete field name at beginning
    line.sub!(/^\s*ORGANISM\s*/,"")
    organism = line
  end
end

puts "*** LOCUS ***\n#{locus}"
puts "*** DEFINITION ***\n#{definition}"
puts "*** ACCESSION ***\n#{accession}"
puts "*** ORGANISM ***\n#{organism}"
