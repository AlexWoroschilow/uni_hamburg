def parse_features(features)
  featuretab = Array.new() # store the individual features here
 
  # Extract features
  features.scan(/^( {5}\S.*\n( {21}\S.*\n)*)/) do |entry|
    featuretab.push(entry[0])   # add it to end of the current featuretable
  end
  return featuretab
end
