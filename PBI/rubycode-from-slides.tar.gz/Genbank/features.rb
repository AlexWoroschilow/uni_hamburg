#!/usr/bin/env ruby
require "splitGB.rb"
require "parseAnno.rb"
require "parseFeatures.rb"
 
if ARGV.length == 1
  filename = ARGV[0]
else
  STDERR.puts "Usage: #{$0} <genbankfile>"
  exit 1
end

# Get the fields from the first GenBank record in a given file
fh = filename2fileobject(filename)

record = get_next_record(fh)

# split record into annotation and sequence
annotation, dna = get_annotation_and_dna(record)

# parse the annotation
fields = parse_annotation(annotation)
 
# Extract the feature entries from the FEATURES table
features = parse_features(fields['FEATURES'])

# Print the features
features.each do |featureentry|
  # extract the name of the feature
  # the following match will be successful. The expression of interest
  # (enclosed in a pair of braces) will be the nonspace sequence 
  # following the 5 white spaces

  mo = featureentry.match(/^ {5}(\S+)/)
  if mo
    puts "******** #{mo[1]} *********"
    puts featureentry
  end
end
