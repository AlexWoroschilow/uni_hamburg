#!/usr/bin/env ruby

require 'set'
require 'rexml/document'

# show tag and correpoding text whenever tag belongs to idset
def showfirstlevel(idset,record)
  record.elements.each do |x|
    if idset.member?(x.name)
      puts "#{x.name}=#{x.text}"
    end
  end
end

# specify for which tags the output will be shown
idset = Set.new ['Seq_locus','Seq_sequence','Seq_division']

File.open("Record.xml","r") do |file|
  xml = REXML::Document.new(file)
  xml.elements.each do |record|   # iterate over all records
    showfirstlevel(idset,record)
  end
  file.close_read
end
