#!/usr/bin/env ruby

require "get_file_data.rb"

# Extract annotation and sequence sections using regexps

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <genbankfile>"
  exit 1
end

# strategy: read entire gb-record into string, and process it
# using regexps. Usually file data is stored line by line,
# since the default input separator is newline. 

# a gb-record begins with the word LOCUS and ends with // on a
# separate line. Read in record to a scalar, using new separator

filename = ARGV[0]
record = get_file_data(filename,"//\n")[0] # get first record
annotation = dna = nil
mo = record.match(/^(LOCUS.*ORIGIN\s*\n)(.*)\/\/\n/m)
if mo
  annotation = mo[1]
  dna = mo[2]
else
  STDERR.puts "#{filename}: Cannot separate annot./seq."
  exit 1
end

print "The annotation:\n#{annotation}", "the DNA:\n#{dna}"
