def parse_annotation(annotation)
  results = Hash.new
  
  # mark beginnings with special character and split there into array
  sep = "\001"
  tops = annotation.gsub(/\n([A-Z])/, "\n#{sep}\\1").split(sep)
  
  # process annotation fields into keyword-indexed hash
  tops.each do |value|
    # the BASE COUNT has a space in it, treat separately
    if value.match(/^BASE COUNT/)
      results['BASE COUNT'] = value
    else
      # get key from line, mo is match object
      mo = value.match(/^([A-Z]+)/)
      if mo
        key = mo[1]
      else
        STDERR.puts "Cannot find key in line \"#{value}\""
        exit 1
      end
      results[key] = value   # store the value in the hash
    end
  end
  return results
end
