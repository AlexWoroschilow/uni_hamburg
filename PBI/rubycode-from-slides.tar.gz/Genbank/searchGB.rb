#!/usr/bin/env ruby
require "splitGB.rb"

# search sequence for regular expression
def search_sequence(sequence, regexp)
  positions = []
  lastpos = 0
  while ((p = sequence.index(/#{regexp}/i,lastpos)) != nil)
    positions.push(p)
    lastpos = p+1
  end
  return positions
end

# search annotation for regular expression
def search_annotation(annotation, regexp)
  positions = []
  # note the /m modifier-. matches any character including newline
  lastpos = 0
  while ((p = annotation.index(/#{regexp}/im,lastpos)) != nil)
    positions.push(p)
    lastpos = p+1
  end
  return positions
end

if ARGV.length == 1
  library = ARGV[0]
else
  STDERR.puts "Usage: #{$0} <genbankfile>"
  exit 1
end

fh = filename2fileobject(library)
# for given file object store next position which has not been read yet
offset = fh.pos   

begin
  while record = get_next_record(fh)   # read records one after the other
    # split record into annotation and dna
    annotation, dna = get_annotation_and_dna(record)
  
    if not (search_sequence(dna, 'AAA[CG].').empty?)
      # show the first position of the record in GB-library
      puts "Sequence found in record at offset #{offset}"
    end
    if not (search_annotation(annotation, 'homo sapiens').empty?)
      puts "Annotation found in record at offset #{offset}"
    end
    offset = fh.pos
  end
rescue EOFError   # close file if end has been reached
  fh.close
end
