#!/bin/sh

run() {
echo "========= $* ==========="
$*
if test $? -ne 0
then
  echo "failure: ${cmd}"
  exit 1
fi
}


set -e -x
run "gb2fasta.rb Record.gb"
run "gb2fields.rb Record.gb"
run "gb2annoseq.rb Record.gb"
run "searchGB.rb Library.gb"
run "getAnno.rb Library.gb"
run "features.rb Library.gb"
run "gb-xml-parse.rb"
