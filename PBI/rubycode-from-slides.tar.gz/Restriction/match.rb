def match_positions_fwd(regexp, sequence)
  positions = Array.new()
  # match regexp against sequence, be case insensitive
  lastpos = 0
  loop do 
    p = sequence.index(/#{regexp}/i,lastpos)
    if p.nil?
      break
    end
    positions.push(p)
    lastpos = p+1
  end
  return positions
end
