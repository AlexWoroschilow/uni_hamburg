#!/usr/bin/env ruby

#add path of this file to searchpath
$:.unshift File.join(File.dirname(__FILE__))
#add filepath/../lib to searchpath
$:.unshift File.join(File.dirname(__FILE__), "..", "lib")

require "extract_sequence.rb"
require "parseREBASE.rb"
require "match.rb"

if ARGV.length != 1
  STDERR.puts "Usage: #{$0} <dnafile>"
  exit 1
end

inputfilename = ARGV[0]
dna = extract_sequence_from_fasta_data(inputfilename) 
rebase_hash = parseREBASE("REBASE.txt") # Get REBASE into hash
loop do
  print "Please enter name of restriction enzyme to search: "
  query = STDIN.gets
  if not query or query.chomp.match(/(^\s*$)|quit/)
    break
  end
  query.chomp!
  if rebase_hash.has_key?(query)
    recognition_site, regexp = rebase_hash[query].split(" ")
    locations = match_positions_fwd(regexp, dna)
    if locations.empty?
      puts "\"#{query}\" does not occur in DNA"
    else
      puts "\"#{regexp}\" was found at pos #{locations.join(', ')}"
    end
  else
    puts "\"#{query}\" is not a valid name"
  end
end
