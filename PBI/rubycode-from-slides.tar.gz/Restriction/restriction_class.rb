#!/usr/bin/env ruby

#add path of this file to searchpath
$:.unshift File.join(File.dirname(__FILE__))
#add filepath/../lib to searchpath
$:.unshift File.join(File.dirname(__FILE__), "..", "lib")

require "extract_sequence.rb"

class RestrictFind
  @@iub2character_class = { # class var: exists only once
    'A' => 'A',
    'C' => 'C',
    'G' => 'G',
    'T' => 'T',
    'R' => '[GA]',
    'Y' => '[CT]',
    'M' => '[AC]',
    'K' => '[GT]',
    'S' => '[GC]',
    'W' => '[AT]',
    'B' => '[CGT]',
    'D' => '[AGT]',
    'H' => '[ACT]',
    'V' => '[ACG]',
    'N' => '[ACGT]'
  }
  
  def initialize(fasta_file, rebase_file = "REBASE.txt")
    @rebase_hash = parseREBASE(rebase_file)
    @dna = extract_sequence_from_fasta_data(fasta_file)
  end

  def get_restriction_matches(query)
    if @rebase_hash.has_key?(query)
      recognition_site, regexp = @rebase_hash[query].split(" ")
      locations = match_positions_fwd(regexp)
    else
      raise "\"#{query}\" not a valid name"
    end
    return [recognition_site, locations]
  end

private

  def match_positions_fwd(regexp)
    positions = Array.new()
    lastpos = 0
    while not (p = @dna.index(/#{regexp}/i,lastpos)).nil?
      positions.push(p)
      lastpos = p+1
    end
    return positions
  end

  def iub_to_regexp(iub)
    regexp_arr = iub.gsub(/\^/,"").split(//)
    regexp_arr.map!{|iubchar| @@iub2character_class[iubchar]}
    return regexp_arr.join 
  end

  def parseREBASE(rebasefile)
    rebase_hash = Hash.new()
    File.new(rebasefile,"r").each_line do |line|
      if not line.match(/^(\s+|REBASE|Rich Roberts)/)
        fields = line.split(" ")    # split the 2 or 3 fields
        re_name = fields.shift      # extract first element
        re_site = fields.pop        # extract last element
        regex = iub_to_regexp(re_site)  # translate recog. site
        rebase_hash[re_name] = "#{re_site} #{regex}"
      end
    end
    return rebase_hash
  end

end   # of class

if $0 == __FILE__
  
  if ARGV.empty?
    STDERR.puts "Usage: #$0 <FastA-File>"
    exit 1
  end

  rf = RestrictFind.new(ARGV[0])
  loop do
    print "Please enter name of restriction enzyme to search: "
    query = STDIN.gets
    if not query or query.chomp.match(/(^\s*$)|quit/)
      break
    end
    query.chomp!
    begin
      site, locations = rf.get_restriction_matches(query)
      if locations.empty?
        puts "\"#{query}\" is not in the DNA"
      else
        puts "\"#{site}\" was found at pos #{locations.join(', ')}"
      end
    rescue => err
      STDERR.puts "#{$0}: #{err}"
      next
    end
  end
end
