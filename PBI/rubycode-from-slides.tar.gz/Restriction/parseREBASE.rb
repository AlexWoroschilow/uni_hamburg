# parse a REBASE datafile parseREBASE-Parse REBASE bionet file

# Here is an extract of a REBASE file, bionet.301.
# ftp://ftp.neb.com/pub/rebase/bionet.301


# REBASE version 301                                              bionet.301

#    =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#    REBASE, The Restriction Enzyme Database   http://rebase.neb.com
#    Copyright (c)  Dr. Richard J. Roberts, 2002.   All rights reserved.
#   =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#Rich Roberts                                                    Dec 27 2002

#AaaI (XmaIII)                     C^GGCCG
#AacI (BamHI)                      GGATCC
#AaeI (BamHI)                      GGATCC
#AagI (ClaI)                       AT^CGAT
#AaqI (ApaLI)                      GTGCAC
#AarI                              CACCTGCNNNN^
#AarI                              ^NNNNNNNNGCAGGTG
#AasI (DrdI)                       GACNNNN^NNGTC
#AatI (StuI)                       AGG^CCT
#AatII                             GACGT^C
#...
#
#YenCI (PstI)                      CTGCAG
#YenDI (PstI)                      CTGCAG
#YenEI (PstI)                      CTGCAG
#ZanI (EcoRII)                     CC^WGG
#ZhoI (ClaI)                       AT^CGAT
#ZraI (AatII)                      GAC^GTC
#Zsp2I (AvaIII)                    ATGCA^T
#
#return a hash where
#  key is restriction enzyme name denoted REname
#  value is whitespace-separated recognition site and regular expression
#

require "iub.rb"

def parseREBASE(rebasefile)
  rebasetab = Hash.new()   # hash to be returned
  File.new(rebasefile,"r").each_line do |line|
    if not line.match(/^(\s+|REBASE|Rich Roberts)/)
      fields = line.split(" ")     # split the 2 or 3 fields
      # Remove parenthesized names by not saving the middle 
      # field (if any), just the first and last
      re_name = fields.shift        # extract first element
      re_site = fields.pop          # extract last element
      regex = iub_to_regexp(re_site)  # translate recog. site
      rebasetab[re_name] = "#{re_site} #{regex}"
    end
  end
  puts "parsed #{rebasetab.length} restriction enzymes"
  return rebasetab  # Return hash with reformatted REBASE
end
