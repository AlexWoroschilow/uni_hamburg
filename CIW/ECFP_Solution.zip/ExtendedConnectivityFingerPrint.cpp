/**
 @file
 @brief
 @author    Bietz
 @date      Mar 29, 2011
 @if DoNotInclude
 Copyright ZBH  Center for Bioinformatics
 University of Hamburg
 Bundesstrasse 43, 20146 Hamburg, Germany
 ================================================================================
 This module is part of the molecule software library Naomi,
 developed at the Center for Bioinformatics Hamburg (ZBH).
 It is not allowed to use, modify, copy or redistribute this software without
 written approval of the ZBH. For further information contact

 ZBH  Center for Bioinformatics, University of Hamburg
 Research Group for Computational Molecular Design

 Voice:  +49 (40) 42838 7350
 Fax:    +49 (40) 42838 7352
 E-Mail: info@zbh.uni-hamburg.de
 ==============================================================================
 @endif
 */

#include "ExtendedConnectivityFingerPrint.hpp"
#include <map>
#include "boost/foreach.hpp"
#include "Naomini/Atom.hpp"
#include "Naomini/Bond.hpp"
#include "Naomini/Molecule.hpp"
#include "Naomini/Helpers.hpp"


using namespace Naomini;

namespace{
unsigned atomGetNofAdjacentHydrogens(AtomPtr a){
  assert(a);
  unsigned counter = 0;
  BOOST_FOREACH(AtomPtr n, a->getNeighborAtoms()){
    if (atomIsHydrogen(n)){counter++;}
  }
  return counter;
}
} // end namespace

/*----------------------------------------------------------------------------*/

ECFP Naomini::getECFP(MoleculePtr m, unsigned nofIterations) {
  // mark ring atoms
  RingVector rings = getRingsOfMolecule(m);

  std::map<AtomPtr, bool> isRingAtom;

  BOOST_FOREACH(Ring r, rings){
    BOOST_FOREACH(AtomPtr a, r){
      isRingAtom[a] = true;
    }
  }

  std::set<Identifier> fingerprint;
  //calculate initial identifiers for all atoms
  std::map<AtomPtr, Identifier > allIdentifiers;

  BOOST_FOREACH(AtomPtr a, m->getAtoms()){
    //skip hydrogens
    if (atomIsHydrogen(a)) {continue;}

    unsigned nofHydrogens = atomGetNofAdjacentHydrogens(a);

    allIdentifiers[a] =  getEcfpInitialIdentifier(
          a->getNeighborAtoms().size()-nofHydrogens, a->getValence() - nofHydrogens,
          a->getAtomicNumber(), a->getAtomicWeight(), a->getAtomicCharge(),
          nofHydrogens, isRingAtom[a]);

    //insert new feature id(hash) to fingerprint set
    fingerprint.insert(allIdentifiers[a]);
  }
  //map for new identifier
  std::map<AtomPtr, Identifier > newIdentifiers;
  // iterative update step

  for (unsigned i = 0; i < nofIterations; i++){

    newIdentifiers.clear();

    BOOST_FOREACH(AtomPtr a, m->getAtoms()){
      //skip hydrogens
      if (atomIsHydrogen(a)) {continue;}

      std::vector< Identifier > neighborIdentifiers;
      neighborIdentifiers.push_back(i+1);
      neighborIdentifiers.push_back(allIdentifiers[a]);

      BOOST_FOREACH(BondPtr b, a->getBonds()){

        AtomPtr neighbor = b->getOpposite(a);
        //skip hydrogens
        if (atomIsHydrogen(neighbor)) {continue;}

        neighborIdentifiers.push_back(getBondIdentifier(b));
        neighborIdentifiers.push_back(allIdentifiers[neighbor]);
      }
      //add new identifier for atom a
      newIdentifiers[a] = combineEcfpIdentifiers(neighborIdentifiers);
    }
    // update identifier
    allIdentifiers = newIdentifiers;

    for (std::map<AtomPtr, Identifier >::iterator it = allIdentifiers.begin();
         it != allIdentifiers.end(); ++it){
      fingerprint.insert(it->second);
    }

  }
  return ECFP(fingerprint.begin(), fingerprint.end());
}

typedef std::set<BondPtr> BondSet;

ECFP Naomini::getECFPWithoutDuplicates(
    MoleculePtr m, unsigned nofIterations)
{
  // mark ring atoms
  RingVector rings = getRingsOfMolecule(m);
  std::map<AtomPtr, bool> isRingAtom;
  BOOST_FOREACH(Ring r, rings){
    BOOST_FOREACH(AtomPtr a, r){
      isRingAtom[a] = true;
    }
  }

  std::set<Identifier> fingerprint;
  //calculate initial identifiers for all atoms
  std::map<AtomPtr, Identifier > allIdentifiers;

  BOOST_FOREACH(AtomPtr a, m->getAtoms()){
    //skip hydrogens
    if (atomIsHydrogen(a)) {continue;}

    unsigned nofHydrogens = atomGetNofAdjacentHydrogens(a);

    allIdentifiers[a] =  getEcfpInitialIdentifier(
          a->getNeighborAtoms().size() - nofHydrogens, a->getValence() - nofHydrogens,
          a->getAtomicNumber(), a->getAtomicWeight(), a->getAtomicCharge(),
          nofHydrogens, isRingAtom[a]);

    //insert new feature id(hash) to fingerprint set
    fingerprint.insert(allIdentifiers[a]);
  }


  std::vector<BondSet> ecfpSubStructs;
  // iteration step
  std::map<AtomPtr, BondSet> allBondSets;
  std::map<AtomPtr, BondSet> newBondSets;
  std::map<AtomPtr, Identifier > newIdentifiers;
  for (unsigned i = 0; i < nofIterations; i++){

    newIdentifiers.clear();


    BOOST_FOREACH(AtomPtr a, m->getAtoms()){

      if (atomIsHydrogen(a)) {continue;}
      //skip hydrogens
      std::vector< Identifier > neighborIdentifiers;
      neighborIdentifiers.push_back(i+1);
      neighborIdentifiers.push_back(allIdentifiers[a]);

      BOOST_FOREACH(BondPtr b, a->getBonds()){
        AtomPtr neighbor = b->getOpposite(a);
        //skip hydrogens
        if (atomIsHydrogen(neighbor)) {continue;}

        if (i==0)
        {
          //init new bondset for atom a
          newBondSets[a].insert(b);
        }
        else{
          //add bondset from neighbor atom...
          BondSet &neighborBondSet =  allBondSets[b->getOpposite(a)];
          //... to current atom a
          newBondSets[a].insert(neighborBondSet.begin(), neighborBondSet.end());
        }
        neighborIdentifiers.push_back(getBondIdentifier(b));
        neighborIdentifiers.push_back(allIdentifiers[neighbor]);
      }
      //add new identifier for atom a
      newIdentifiers[a] = combineEcfpIdentifiers(neighborIdentifiers);
    }
    allIdentifiers = newIdentifiers;
    allBondSets = newBondSets;

    for (std::map<AtomPtr, BondSet >::iterator it = allBondSets.begin();
         it != allBondSets.end(); ++it){

      BondSet &bondSet = it->second;
      bool newSubStruct = true;

      BOOST_FOREACH(BondSet subStruct, ecfpSubStructs){
        if (subStruct == bondSet){
          newSubStruct = false;
          break;
        }
      }
      if (newSubStruct)
      {
        Identifier newID = allIdentifiers[it->first];
        for (std::map<AtomPtr, BondSet>::iterator alternativIt = newBondSets.begin();
             alternativIt!= newBondSets.end(); ++alternativIt){
          if (alternativIt->second == bondSet &&  allIdentifiers[alternativIt->first] < newID)
          {
            newID = allIdentifiers[alternativIt->first];
          }
        }
        if (!fingerprint.count(newID))
        {
          ecfpSubStructs.push_back(bondSet);
          fingerprint.insert(newID);
        }
      }
    }

  }
  return ECFP(fingerprint.begin(), fingerprint.end());
}

