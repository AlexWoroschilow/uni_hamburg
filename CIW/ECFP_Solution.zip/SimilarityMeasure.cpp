/**
 @file
 @brief     
 @author    Bietz
 @date      Mar 25, 2011
 @if DoNotInclude
 Copyright ZBH  Center for Bioinformatics
 University of Hamburg
 Bundesstrasse 43, 20146 Hamburg, Germany
 ================================================================================
 This module is part of the molecule software library Naomi,
 developed at the Center for Bioinformatics Hamburg (ZBH).
 It is not allowed to use, modify, copy or redistribute this software without
 written approval of the ZBH. For further information contact

 ZBH  Center for Bioinformatics, University of Hamburg
 Research Group for Computational Molecular Design

 Voice:  +49 (40) 42838 7350
 Fax:    +49 (40) 42838 7352
 E-Mail: info@zbh.uni-hamburg.de
 ==============================================================================
 @endif
 */

#include "SimilarityMeasure.hpp"
#include <assert.h>
#include <math.h>
namespace Naomini{

namespace{
unsigned getNofMatches(const ECFP &a, const ECFP &b){
  ECFP::const_iterator itA = a.begin();
  ECFP::const_iterator itB = b.begin();

  unsigned nofMatches = 0;
  while (itA != a.end() && itB != b.end()){
    if (*itA < *itB){++itA;}
    else{
      if (*itA > *itB){++itB;}
      else{
        assert(*itA == *itB);
        ++nofMatches;
        ++itA;
        ++itB;
      }
    }
  }
  return nofMatches;
}
}//end namespace

double getTanimotoCoefficient(const ECFP &a, const ECFP &b){
  unsigned nofMatches = getNofMatches(a,b);
  return (nofMatches /static_cast<double>(a.size() + b.size() - nofMatches));
}

double getCosineCoefficient(const ECFP &a, const ECFP &b){
  unsigned nofMatches = getNofMatches(a,b);
  double product = a.size() * b.size();
  return (nofMatches /static_cast<double>(sqrt(product)));
}

double getHammingDistance(const ECFP &a, const ECFP &b){
  unsigned nofMatches = getNofMatches(a,b);
  return (static_cast<double>(a.size() + b.size() - (2 * nofMatches) ));
}
}
