/**
 @file
 @brief     
 @author    Bietz
 @date      Mar 30, 2011
 @if DoNotInclude
 Copyright ZBH  Center for Bioinformatics
 University of Hamburg
 Bundesstrasse 43, 20146 Hamburg, Germany
 ================================================================================
 This module is part of the molecule software library Naomi,
 developed at the Center for Bioinformatics Hamburg (ZBH).
 It is not allowed to use, modify, copy or redistribute this software without
 written approval of the ZBH. For further information contact

 ZBH  Center for Bioinformatics, University of Hamburg
 Research Group for Computational Molecular Design

 Voice:  +49 (40) 42838 7350
 Fax:    +49 (40) 42838 7352
 E-Mail: info@zbh.uni-hamburg.de
 ==============================================================================
 @endif
 */

#include <iomanip>
#include <stdio.h>
#include "boost/foreach.hpp"
#include "boost/numeric/ublas/matrix.hpp"

#include "Naomini/MoleculeFactory.hpp"
#include "Naomini/Helpers.hpp"
#include "Naomini/MoleculeDrawer.hpp"
#include "Naomini/Molecule.hpp"

#include "ExtendedConnectivityFingerPrint.hpp"
#include "SimilarityMeasure.hpp"

// static functions
namespace{
using namespace Naomini;

typedef boost::numeric::ublas::matrix<double> SimilarityMatrix;

void printSimilarityMatrix(SimilarityMatrix &m){
  std::cout.precision(2);
  std::cout << "     ║";
  for (unsigned j = 0; j < m.size2(); j++){
    std::cout << std::setw( 5 )  << j+1 << "  │";}
  std::cout << "\n═════╬══════";
  for (unsigned j = 1; j < m.size2(); j++){std::cout << "═╪══════";}
  std::cout << "═╡\n";
  for (unsigned i = 0; i < m.size1(); i++){
    std::cout << " "  << std::setw( 3 )  << i+1 <<" ║";
    for (unsigned j = 0; j < m.size2(); j++){
      std::cout << std::setw( 7 ) << m(i,j) << std::fixed << "│";
//      printf("%5.2f", m(i,j));
//      std::cout << " │";
    }
    std::cout << "\n─────╫──────";
    for (unsigned j = 1; j < m.size2(); j++){
      std::cout << "─┼──────";
    }
    std::cout << "─┤\n";
  }

}
} // end namespace

namespace Naomini{
void analyseMoleculeSimilarity(MoleculeVector molecules,
    unsigned nofIterations){
  unsigned nofMolecules = molecules.size();

/**** calculate an ECFP for each molecule *************************************/
  std::vector<ECFP> fingerprints;
  try{
    BOOST_FOREACH(MoleculePtr mol, molecules){
      ECFP fp = getECFPWithoutDuplicates(mol, nofIterations);
      fingerprints.push_back(fp);
      std::cout << "_____________________________" << std::endl;
      std::cout << mol->getName() << std::endl << std::endl;
      BOOST_FOREACH(Identifier i, fp){
        std::cout << i << std::endl;
      }
    }
  }
  catch (const char *err){
    std::cout << err << std::endl;
  }

/****  calculate the Tanimoto coefficient for each pair of molecules  ***********/

  SimilarityMatrix tanimotoMatrix(nofMolecules, nofMolecules);
  for (unsigned i = 0; i < nofMolecules; i++){
    for (unsigned j = i; j < nofMolecules; j++){
      tanimotoMatrix(i,j) = getTanimotoCoefficient(fingerprints[i],
                                                   fingerprints[j]);
      tanimotoMatrix(j,i) = tanimotoMatrix(i,j);
    }
  }
  std::cout << "Tanimoto coefficients: " << std::endl;
  printSimilarityMatrix(tanimotoMatrix);



/****  calculate the cosine coefficient for each pair of molecules  ***********/

  SimilarityMatrix cosineMatrix(nofMolecules, nofMolecules);
  for (unsigned i = 0; i < nofMolecules; i++){
    for (unsigned j = i; j < nofMolecules; j++){
      cosineMatrix(i,j) = getCosineCoefficient(fingerprints[i],
                                                   fingerprints[j]);
      cosineMatrix(j,i) = cosineMatrix(i,j);

    }
  }
  std::cout << std::endl << std::endl << "Cosine coefficients: " << std::endl;
  printSimilarityMatrix(cosineMatrix);


/****  calculate the hamming distance for each pair of molecules  *************/
  SimilarityMatrix hammingMatrix(nofMolecules, nofMolecules);

  for (unsigned i = 0; i < nofMolecules; i++){
    for (unsigned j = i; j < nofMolecules; j++){
      hammingMatrix(i,j) = getHammingDistance(fingerprints[i],
                                                   fingerprints[j]);
      hammingMatrix(j,i) = hammingMatrix(i,j);
    }
  }

  std::cout << std::endl << std::endl <<"Hamming Distances: " << std::endl;
  printSimilarityMatrix(hammingMatrix);

/****  analyze similarities / distances ***************************************/
//  unsigned nofTdiff = 0, nofCdiff = 0, nofHdiff = 0, allDiff = 0;
//  for (unsigned i = 0; i < nofMolecules -1; i++){
//    double best_t = 0, best_c = 0, best_h = 100000;
//    unsigned id_t = 0, id_c = 0, id_h = 0;

//      for (unsigned j = i+1; j < nofMolecules; j++){
//        if (tanimotoMatrix(i, j) > best_t){
//          best_t = tanimotoMatrix(i, j);
//          id_t = j;
//        }
//        if (cosineMatrix(i, j) > best_c){
//          best_c = cosineMatrix(i, j);
//          id_c = j;
//        }
//        if (hammingMatrix(i, j) < best_h){
//                  best_h = hammingMatrix(i, j);
//                  id_h = j;
//        }
//      }
//      if (id_t != id_c && id_t != id_h && id_c != id_h){
//        allDiff++;
//      }
//      else if (id_t == id_c && id_t != id_h){
//        nofHdiff++;
//      }
//      else if (id_t == id_h && id_t != id_c){
//        nofCdiff++;
//      }
//      else if (id_c == id_h && id_t != id_h){
//        nofTdiff++;
//      }
////      MoleculeDrawer a(molecules[i]);
////      MoleculeDrawer b(molecules[id_t]);
////      wait();
//    }
//  std::cout << "All equal:  " <<
//      nofMolecules - nofTdiff - nofCdiff - nofHdiff -  allDiff - 1
//      << " time(s)." << std::endl;
//  std::cout << "Tanimoto differs " << nofTdiff << " time(s)." << std::endl;
//  std::cout << "Cosine differs " << nofCdiff << " time(s)." << std::endl;
//  std::cout << "Hamming differs " << nofHdiff << " time(s)." << std::endl;
//  std::cout << "All different: " << allDiff << " time(s)." << std::endl;

}

} // end namespace Naomini

int main(int argc, char *argv[]) {
  // check the number of arguments
  if (argc != 3){
    std::cout << "Usage: " << argv[0] << " <molecule-file> <number of iterations>" << std::endl;
    return 1;
  }

  // read the number of ecfp-iterations from argument 2
  unsigned nofIterations = atoi(argv[2]);
  if (nofIterations < 0 || nofIterations > 10){
    std::cout << "Use a sensible number of iterations." << std::endl
        << "Usage: " << argv[0] << " <molecule-file> <number of iterations>" << std::endl;
    return 1;
  }

  // get a molecule for each molecule entry in the provided file
  MoleculeVector mols = MoleculeFactory::getAllMolecules(std::string(argv[1]));
  if ( mols.size() < 1){
    std::cout << "No molecules could be read from \"" << argv[1] <<"\"."  <<   std::endl
        << "Usage: " << argv[0] << " <molecule-file> <number of iterations>" << std::endl;
    return 1;
  }

  Naomini::analyseMoleculeSimilarity(mols, nofIterations);
  return 0;
}

