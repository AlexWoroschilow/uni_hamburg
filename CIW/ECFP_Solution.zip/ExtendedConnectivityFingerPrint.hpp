/**
 @file
 @brief     
 @author    Bietz
 @date      Mar 29, 2011
 @if DoNotInclude
 Copyright ZBH  Center for Bioinformatics
 University of Hamburg
 Bundesstrasse 43, 20146 Hamburg, Germany
 ================================================================================
 This module is part of the molecule software library Naomi,
 developed at the Center for Bioinformatics Hamburg (ZBH).
 It is not allowed to use, modify, copy or redistribute this software without
 written approval of the ZBH. For further information contact

 ZBH  Center for Bioinformatics, University of Hamburg
 Research Group for Computational Molecular Design

 Voice:  +49 (40) 42838 7350
 Fax:    +49 (40) 42838 7352
 E-Mail: info@zbh.uni-hamburg.de
 ==============================================================================
 @endif
 */

#ifndef NAOMINI_EXTENDEDCONNECTIVITYFINGERPRINT_HPP_
#define NAOMINI_EXTENDEDCONNECTIVITYFINGERPRINT_HPP_

#include "Naomini/Forward.hpp"
#include <set>
namespace Naomini {

/* A simple unsigned integer is used as Identifier.*/
typedef unsigned Identifier;

/* An ECFP is just a set of Identifiers.*/
typedef std::vector<Identifier> ECFP;

/** This function calculates an Extended Connectivity Fingerprint of a
 * molecule m. The number of iterations (nofIterations) defines how often
 * the iterative update procedure of the ecfp algorithm is executed.
 */
  ECFP getECFP(MoleculePtr m, unsigned nofIterations);

  /** This function calculates an Extended Connectivity Fingerprint of a
   * molecule m. The number of iterations (nofIterations) defines how often
   * the iterative update procedure of the ecfp algorithm is executed.
   * Duplicates are removed.
   */
  ECFP getECFPWithoutDuplicates(MoleculePtr m, unsigned nofIterations);
}

#endif /* NAOMINI_EXTENDEDCONNECTIVITYFINGERPRINT_HPP_ */
